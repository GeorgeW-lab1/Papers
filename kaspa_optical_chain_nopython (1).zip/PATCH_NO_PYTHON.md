# No-Python optical-chain patch

This zip contains the original sketch plus the modifications needed to run
ENGINE CHAIN without gate_program.h, chain_program.h, or kaspa_gatec.py.

## What changes
1. Remove the two optional #include blocks and HAVE_GATES/HAVE_CHAIN probes.
2. Replace them with runtime-built gate programs (C only).
3. Change struct GProg pointers from const to mutable.
4. Add builder_begin/emit/wxor/wand/wnot/build_keccak_round.
5. Build the Keccak round program and target comparator in setup().
6. Replace gates_run() so the 64x64 nibble matrix product uses the existing
   optical nibble engine (matvec_optical) instead of a Python-generated
   heavy-stage gate netlist.
7. Copy the active pre_pow and target into gp_prepow and cp_target before RUN.

## Apply order
- Open rpi_pico_kaspa_optical_chain.ino.
- Apply the replacements from the chat patch exactly.
- Compile for Raspberry Pi Pico (Earle Philhower Arduino-Pico core).
- Serial: OPTCAL, ENGINE CHAIN, MAXNONCES 1, RUN, CPUSTATS.

## Expected
- native_keccak_perms = 0 during chain runs.
- optical_gate_evals and adc_ms increase substantially.
- The matrix stage is optical; Keccak rounds and comparator are optical gate
  programs generated at runtime.

## Performance warning
A Keccak-f1600 round is thousands of two-input gates. Expect extremely slow
throughput; this demonstrates optical offload, not a fast miner.
