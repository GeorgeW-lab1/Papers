// Raspberry Pi Pico / RP2040 - Kaspa kHeavyHash optical bench, standalone + nibble optical engine.
// Build with the Earle Philhower Arduino-Pico core.
//
// Everything that used to live in kaspa_bench_offload_pico.py now runs on the Pico:
//   - job setup (demo template / pre-PoW hash / 80-byte work order, target by
//     leading zero bits or exact hex)
//   - matrix generation + GF(2) full-rank check
//   - nonce search (cSHAKE256 -> 64x64 matrix -> XOR -> cSHAKE256 -> target compare)
//   - independent re-verification of any hit (second Keccak/cSHAKE/matrix
//     implementation with runtime-derived constants)
//   - ITO PWM updates, photodiode / camera sampling, CSV rows, JSON report
//
// With AUTO_RUN_ON_BOOT=1 it runs the demo job by itself at power-up and prints
// the report over USB serial. A PC is optional (serial monitor, 115200 baud).
//
// Wiring:
//   Photodiodes: 8:1 74HC4051 mux COM -> GP26/ADC0, select S0/S1/S2 -> GP10/11/12
//   ITO pixels : GP2..GP9 (PWM; use external drivers)
//
// Serial commands (all optional):
//   PING
//   MODE PHOTODIODES | MODE CAMERA | MODE NONE
//   PREPOW <64 hex>            WORKORDER <160 hex>      DEMO
//   TIMESTAMP <hex or decimal> TARGETBITS <1..255>      TARGET <64 hex>
//   START <n>  MAXNONCES <n>   BATCH <n>   ITOEVERY <n>
//   RUN                         run a full search with the current settings
//   STOP is any byte sent while RUN is active
//   JOB <pre_pow 64h> <ts 16h> <target 64h> <start 16h> <count 16h>   (legacy, matrix from MATRIXROW)
//   MATRIXROW <0..63> <128 hex>   GENMATRIX   SAMPLE   SETITO a b c d e f g h   ITOCLEAR
//
// Replies: OK,... ERR,... D,... F,... CSV,... FOUND,... NONE,... REPORT,{json}
//
// NIBBLE / OPTICAL ENGINE
//   The only heavy arithmetic in kHeavyHash is the 64x64 matrix x 64-vector product
//   over 4-bit values. This version keeps the matrix packed as nibbles and can run
//   that product on the optical bench instead of the CPU:
//     - one ITO pixel k carries the vector nibble v (PWM level = 17*v)
//     - pixel k is lit for w slots out of 15, where w is the matrix nibble
//     - photodiode k integrates that light, so its reading ~ v*w (optical multiply)
//     - the Pico only sums the 8 lane products per tile (512 tiles per matvec)
//   Assumes pixel k is optically paired 1:1 with photodiode k and that each photodiode
//   channel has an integrating/hold front end that is discharged between tiles.
//   Consensus needs EXACT integers, so analog results are never authoritative on their
//   own: by default every optical matvec is cross-checked against the digital nibble
//   engine, and any hit is re-verified by the independent reference implementation.
//
//   ENGINE DIGITAL | ENGINE OPTICAL   OPTCAL   OPTTEST
//   OPTSLOT <us per slot>   OPTEVERY <n: optical every n-th hash>   OPTTRUST 0|1
//   (OPTTRUST 1 skips the digital cross-check; wrong optical results can then only
//    cause missed hits, because hits are still re-verified before being accepted.)
//
// GATE ENGINE (logic-gate circuit compiled by kaspa_gatec.py)
//   ENGINE GATES        run the matvec+XOR stage as a netlist of AND/OR/XOR/NAND/NOR/XNOR gates
//   GATEMODE OPTICAL|DIGITAL   OPTICAL: 8 gates per wave, one lane = one pixel + photodiode
//   GATETEST            one random vector through the circuit, compared with the nibble engine
//   One lane: slot A drives pixel k with input a, slot B with input b; photodiode k integrates
//   s = a + b, classified 0/1/2 by calibrated thresholds, then the gate's truth table is applied.
//   OPTTRUST 0 (default) cross-checks every optical gate decision and continues with the exact
//   value; OPTTRUST 1 continues with the optical value (errors then only cause missed hits).
//
// CHAIN ENGINE (CPU-minimal): ENGINE CHAIN
//   Needs gate_program.h (python kaspa_gatec.py --stage heavy --emit-c gate_program.h) and
//   chain_program.h (python kaspa_gatec.py --stage chain --emit-c chain_program.h, same target!).
//   Keccak (24 rounds x2), the matrix stage and the target comparison all run as optical gate
//   programs. Optical front end: two LEDs (LED_A, LED_B) behind the ITO plate; plate pixel k shows
//   input a during LED A's pulse and input b during LED B's pulse; photodiode k integrates a+b.
//   SHADOW 1 (default): the CPU also computes each ideal gate output, for stats and error repair
//                       (validation mode, CPU does the same logic twice).
//   SHADOW 0 + OPTTRUST 1: optics only; the CPU just loads inputs, thresholds readings, moves bits.
//                       Wrong optical results can then only cause missed hits; every hit is rechecked
//                       natively before it is accepted.
//   TRACE n    print the next n device events (T,t_us,device,action,a,b)
//   SKELETON   print the call skeleton with who does what (CPU / LED / ITO / PD)
//   CPUSTATS   CPU vs optics accounting; RUN's report has the same under "cpu"
//
// MIX ENGINE
//   MIX <nibble_every> <gate_every>   every n-th hash runs on that optical engine, the rest on the CPU
//   e.g. MIX 64 512: 1/64 of hashes use the nibble optical engine, 1/512 use the gate engine.
//   Gate takes priority when both fall on the same hash. 0 switches an engine off.
//   OPTTRUST 0 (default) keeps the CPU result authoritative, so a MIX run finds the same nonces as a
//   CPU-only run; the exchange stats show how the optical share performed. RUN's report adds a "mix"
//   object with hashes and milliseconds per engine.
//
// EXCHANGE STATS
//   EXSTATS   table of the bench exchanges actually used: attempts, ok, fail, fail/ok (EXSTATS ALL: every row)
//   EXRESET   zero the counters (also done automatically at the start of RUN)
//   EXLOG n   print the next n failed exchanges as XF,<kind>,<index>,<lane>,got=..,want=..
//   RUN also prints the same counters in its REPORT json ("exchanges").
//
// Optical readings do not validate proof-of-work by themselves.

#include <Arduino.h>
#include <string.h>
#include <strings.h>

// Optional compiled gate program (python kaspa_gatec.py --stage heavy --emit-c gate_program.h).
// Put gate_program.h next to this sketch. Without it, ENGINE GATES reports an error.
#if defined(__has_include)
#if __has_include("gate_program.h")
#include "gate_program.h"
#define HAVE_GATES 1
#endif
#endif
#ifndef HAVE_GATES
#define HAVE_GATES 0
#endif

// Optional chain program (python kaspa_gatec.py --stage chain --emit-c chain_program.h):
// Keccak round + comparator as gates. Needs gate_program.h too (heavy stage).
#if HAVE_GATES && defined(__has_include)
#if __has_include("chain_program.h")
#include "chain_program.h"
#define HAVE_CHAIN 1
#endif
#endif
#ifndef HAVE_CHAIN
#define HAVE_CHAIN 0
#endif

#if HAVE_GATES
#define GW_A GP_N_WIRES
#else
#define GW_A 0
#endif
#if HAVE_CHAIN
#define GW_B RP_N_WIRES
#else
#define GW_B 0
#endif
#define GW_BITS ((GW_A) > (GW_B) ? (GW_A) : (GW_B))

#define AUTO_RUN_ON_BOOT 1
#define RATE 136
#define NUM_ITO 8
#define NUM_PD 8

// Must be defined before any function: the Arduino build inserts function prototypes at the
// top of the file, and prototypes that mention Ex would fail if it were declared later.
struct Ex { uint64_t ok, fail; };

// One compiled gate program (netlist). Defined at the top for the Arduino prototype generator.
struct GProg {
  const uint32_t *gates;      // 2 words per gate: (op<<28)|a, b
  const uint32_t *wave_end;   // cumulative gate count at the end of each wave (<= 8 gates)
  const uint32_t *out;        // output wire ids
  uint32_t n_gates, n_waves, n_in, n_out, first_wire;
};

#if defined(ARDUINO_ARCH_ESP32)
// ESP32-C3 pin map. GPIO11-17 are wired to the SPI flash: driving them hangs the chip
// (watchdog reset loop). GPIO9 is the boot-mode strapping pin: do not let a driver hold it low.
// GPIO2/8 are also strapping pins: keep their drivers off/high-Z during reset.
// GPIO20/21 are UART0; if your board uses UART0 for Serial, move those two ITO pixels.
// Check this against YOUR board's pinout before wiring.
static const int PHOTO_ADC_PIN = 0;                          // ADC1_CH0
static const int MUX_SELECT_PINS[3] = {1, 3, 4};
static const int ITO_PINS[NUM_ITO] = {5, 6, 7, 10, 20, 21, 2, 8};
// LED A / LED B: the two light sources behind the ITO plate. GPIO18/19 are the USB pins on the C3:
// if you use USB serial, move these (the C3 is very short of free pins).
static const int LED_A_PIN = 18;
static const int LED_B_PIN = 19;
#else
// RP2040 (Raspberry Pi Pico)
static const int PHOTO_ADC_PIN = 26;
static const int MUX_SELECT_PINS[3] = {10, 11, 12};
static const int ITO_PINS[NUM_ITO] = {2, 3, 4, 5, 6, 7, 8, 9};
static const int LED_A_PIN = 13;   // LED A (GP13), LED B (GP14): the two sources behind the ITO plate
static const int LED_B_PIN = 14;
#endif

// ---------------------------------------------------------------------------
// Settings / state
// ---------------------------------------------------------------------------

enum Source { SRC_NONE, SRC_PHOTODIODES, SRC_CAMERA };

static Source source = SRC_PHOTODIODES;
static uint8_t matrix[64][64];
static bool matrix_loaded = false;

static uint8_t pre_pow[32];
static uint8_t target[32];
static uint64_t timestamp = 1700000000ULL;  // no RTC on Pico; set with TIMESTAMP
static uint64_t start_nonce = 0;
static uint64_t max_nonces = 1000000ULL;
static uint32_t batch_size = 1024;           // progress/STOP polling interval
static uint32_t ito_every = 1;

enum Engine { ENG_DIGITAL, ENG_OPTICAL, ENG_GATES, ENG_MIX, ENG_CHAIN };
static Engine engine = ENG_DIGITAL;
static uint8_t mnib[64][32];                  // matrix packed two nibbles per byte
static uint32_t opt_slot_us = 40;             // light-on time per slot
static uint32_t opt_discharge_us = 2000;      // integrator reset time between tiles
static uint32_t opt_every = 1;
static bool opt_trust = false;
static bool opt_cal_ok = false;
static uint16_t opt_dark[NUM_PD], opt_full[NUM_PD];
static uint32_t opt_counter = 0;
static uint64_t opt_hashes = 0, opt_mismatch = 0, opt_false_hits = 0;

// MIX engine: share the hashes between the CPU and the optical engines.
static uint32_t mix_nib_every = 0, mix_gate_every = 0;   // 0 = engine not used in the mix
static uint32_t mix_counter = 0;
static bool mix_forced = false;                          // true while MIX has chosen the engine
static uint64_t eng_hashes[3], eng_us[3];                // 0 digital, 1 nibble optical, 2 gates

static void pack_row(int i) {
  for (int j = 0; j < 64; j += 2)
    mnib[i][j >> 1] = (uint8_t)((matrix[i][j] & 0x0f) | ((matrix[i][j + 1] & 0x0f) << 4));
}

static void pack_matrix() {
  for (int i = 0; i < 64; i++) pack_row(i);
}

static inline uint8_t mget(int i, int j) { return (mnib[i][j >> 1] >> ((j & 1) * 4)) & 0x0f; }

static bool generate_matrix(int max_attempts, int *attempts_used);
static void print_u64_dec(uint64_t v);

static char line_buf[400];
static size_t line_len = 0;

// ---------------------------------------------------------------------------
// Optics
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Exchange statistics: every drive/readout transaction with the optical bench is counted
// as ok or fail. fail/ok is the ratio the EXSTATS command prints.
//   adc_read             one photodiode ADC conversion; fail = saturated (>= 4090 counts)
//   calibration          one calibration attempt; fail = not enough optical swing
//   nibble_product_lane  one lane of the nibble engine; fail = estimated v*w != exact v*w
//   nibble_tile          one 8-lane tile; fail = any lane wrong
//   gate_lane            one optical gate decision; fail = differs from the ideal gate output
//   gate_wave            one 8-lane wave; fail = any lane wrong
//   stage_eval           one matvec+XOR evaluation on the bench; fail = any wrong result in it
//   hit_check            one candidate hit; fail = independent check rejected it (false hit)
// ---------------------------------------------------------------------------
static Ex ex_adc, ex_cal, ex_prod, ex_tile, ex_gate, ex_wave, ex_eval, ex_hit;
static int32_t ex_log_left = 0;

#define EX_LIST(X) X("adc_read", ex_adc) X("calibration", ex_cal) \
  X("nibble_product_lane", ex_prod) X("nibble_tile", ex_tile) \
  X("gate_lane", ex_gate) X("gate_wave", ex_wave) \
  X("stage_eval", ex_eval) X("hit_check", ex_hit)

static inline void ex_note(Ex &e, bool ok) { if (ok) e.ok++; else e.fail++; }

static void ex_reset() {
#define X(n, e) e.ok = 0; e.fail = 0;
  EX_LIST(X)
#undef X
}

static void ex_fail_log(const char *kind, uint32_t idx, int lane, int got, int want) {
  if (ex_log_left <= 0) return;
  ex_log_left--;
  Serial.print("XF,"); Serial.print(kind); Serial.print(',');
  Serial.print((unsigned)idx); Serial.print(',');
  Serial.print(lane); Serial.print(",got=");
  Serial.print(got); Serial.print(",want="); Serial.println(want);
}

static void ex_ratio(const Ex &e) {
  if (e.ok == 0 && e.fail == 0) Serial.print("n/a");
  else if (e.ok == 0) Serial.print("inf");
  else Serial.print((float)((double)e.fail / (double)e.ok), 6);
}

static void ex_row(const char *name, const Ex &e) {
  Serial.print("EX,"); Serial.print(name); Serial.print(',');
  print_u64_dec(e.ok + e.fail); Serial.print(',');
  print_u64_dec(e.ok); Serial.print(',');
  print_u64_dec(e.fail); Serial.print(',');
  ex_ratio(e); Serial.println();
}

static void ex_print(bool all) {
  Serial.println("EX,exchange,attempts,ok,fail,fail_over_ok");
  int shown = 0;
#define X(n, e) if (all || (e.ok + e.fail) > 0) { ex_row(n, e); shown++; }
  EX_LIST(X)
#undef X
  if (!shown) Serial.println("EX,(none used yet)");
}

static void ex_json() {
  Serial.print(",\"exchanges\":{");
  bool first = true;
#define X(n, e) if ((e.ok + e.fail) > 0) { if (!first) Serial.print(','); first = false; \
  Serial.print("\"" n "\":{\"ok\":"); print_u64_dec(e.ok); \
  Serial.print(",\"fail\":"); print_u64_dec(e.fail); Serial.print('}'); }
  EX_LIST(X)
#undef X
  Serial.print('}');
}

// ---------------------------------------------------------------------------
// Trace and CPU/optics accounting
//   TRACE n   print the next n device events: T,<t_us>,<device>,<action>,<a>,<b>
//             devices: CPU, LED_A, LED_B, ITO (plate pixel), MUX, PD (photodiode), PROG
//   The counters split the work: what the optics did, what the CPU did as glue/readout, and what
//   the CPU computed natively (Keccak permutations, matvec, gate evaluation).
// ---------------------------------------------------------------------------
static int32_t trace_left = 0;
static uint64_t cpu_native_keccak = 0, cpu_native_matvec = 0, cpu_native_gates = 0;
static uint64_t cpu_glue_ops = 0, cpu_readout_ops = 0, cpu_ref_verifies = 0;
static uint64_t opt_gate_evals = 0, opt_wait_us = 0, adc_us = 0, run_total_us = 0;

static void tr_emit(const char *dev, const char *act, int a, int b) {
  trace_left--;
  Serial.print("T,"); Serial.print((unsigned long)micros()); Serial.print(',');
  Serial.print(dev); Serial.print(','); Serial.print(act); Serial.print(',');
  Serial.print(a); Serial.print(','); Serial.println(b);
}
#define TR(dev, act, a, b) do { if (trace_left > 0) tr_emit(dev, act, a, b); } while (0)

static void cpu_reset() {
  cpu_native_keccak = cpu_native_matvec = cpu_native_gates = 0;
  cpu_glue_ops = cpu_readout_ops = cpu_ref_verifies = 0;
  opt_gate_evals = opt_wait_us = adc_us = run_total_us = 0;
}

static float cpu_busy_pct() {
  if (run_total_us == 0) return 0.0f;
  uint64_t idle = opt_wait_us + adc_us;
  if (idle > run_total_us) idle = run_total_us;
  return 100.0f * (float)(run_total_us - idle) / (float)run_total_us;
}

static void cpu_json() {
  Serial.print(",\"cpu\":{\"native_keccak_perms\":"); print_u64_dec(cpu_native_keccak);
  Serial.print(",\"native_matvecs\":"); print_u64_dec(cpu_native_matvec);
  Serial.print(",\"native_gate_evals\":"); print_u64_dec(cpu_native_gates);
  Serial.print(",\"glue_bit_ops\":"); print_u64_dec(cpu_glue_ops);
  Serial.print(",\"readout_ops\":"); print_u64_dec(cpu_readout_ops);
  Serial.print(",\"ref_verifies\":"); print_u64_dec(cpu_ref_verifies);
  Serial.print(",\"optical_gate_evals\":"); print_u64_dec(opt_gate_evals);
  Serial.print(",\"optical_wait_ms\":"); print_u64_dec(opt_wait_us / 1000);
  Serial.print(",\"adc_ms\":"); print_u64_dec(adc_us / 1000);
  Serial.print(",\"cpu_busy_pct\":"); Serial.print(cpu_busy_pct(), 1);
  Serial.print('}');
}

static void cpu_print() {
  Serial.print("CPU,native_keccak_perms="); print_u64_dec(cpu_native_keccak);
  Serial.print(",native_matvecs="); print_u64_dec(cpu_native_matvec);
  Serial.print(",native_gate_evals="); print_u64_dec(cpu_native_gates);
  Serial.print(",glue_bit_ops="); print_u64_dec(cpu_glue_ops);
  Serial.print(",readout_ops="); print_u64_dec(cpu_readout_ops);
  Serial.print(",ref_verifies="); print_u64_dec(cpu_ref_verifies);
  Serial.print(",optical_gate_evals="); print_u64_dec(opt_gate_evals);
  Serial.print(",optical_wait_ms="); print_u64_dec(opt_wait_us / 1000);
  Serial.print(",adc_ms="); print_u64_dec(adc_us / 1000);
  Serial.print(",cpu_busy_pct="); Serial.println(cpu_busy_pct(), 1);
}

static uint16_t sample_pd(int channel) {
  channel &= 7;
  uint32_t t0 = micros();
  for (int bit = 0; bit < 3; ++bit) digitalWrite(MUX_SELECT_PINS[bit], (channel >> bit) & 1);
  TR("MUX", "select", channel, 0);
  delayMicroseconds(8);
  uint16_t v = analogRead(PHOTO_ADC_PIN);
  adc_us += (uint32_t)(micros() - t0);
  TR("PD", "read", channel, v);
  ex_note(ex_adc, v < 4090);
  return v;
}

static void update_optics(const uint8_t h[32]) {
  for (int i = 0; i < NUM_ITO; i++) analogWrite(ITO_PINS[i], h[i]);
}

static void clear_optics() {
  for (int i = 0; i < NUM_ITO; i++) analogWrite(ITO_PINS[i], 0);
}

static void leds(bool a, bool b) {
  digitalWrite(LED_A_PIN, a ? HIGH : LOW);
  digitalWrite(LED_B_PIN, b ? HIGH : LOW);
}

// ---------------------------------------------------------------------------
// Keccak-f[1600] (fast table version)
// ---------------------------------------------------------------------------

static const uint64_t RC[24] = {
  0x0000000000000001ULL, 0x0000000000008082ULL, 0x800000000000808aULL,
  0x8000000080008000ULL, 0x000000000000808bULL, 0x0000000080000001ULL,
  0x8000000080008081ULL, 0x8000000000008009ULL, 0x000000000000008aULL,
  0x0000000000000088ULL, 0x0000000080008009ULL, 0x000000008000000aULL,
  0x000000008000808bULL, 0x800000000000008bULL, 0x8000000000008089ULL,
  0x8000000000008003ULL, 0x8000000000008002ULL, 0x8000000000000080ULL,
  0x000000000000800aULL, 0x800000008000000aULL, 0x8000000080008081ULL,
  0x8000000000008080ULL, 0x0000000080000001ULL, 0x8000000080008008ULL
};

static const int ROTC[24] = {
  1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14, 27, 41, 56, 8,
  25, 43, 62, 18, 39, 61, 20, 44
};

static const int PILN[24] = {
  10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4, 15, 23, 19, 13,
  12, 2, 20, 14, 22, 9, 6, 1
};

#define ROL64(x, n) (((x) << (n)) | ((x) >> (64 - (n))))

static void keccakf(uint64_t st[25]) {
  cpu_native_keccak++;
  uint64_t t, bc[5];
  for (int round = 0; round < 24; round++) {
    for (int i = 0; i < 5; i++) bc[i] = st[i] ^ st[i + 5] ^ st[i + 10] ^ st[i + 15] ^ st[i + 20];
    for (int i = 0; i < 5; i++) {
      t = bc[(i + 4) % 5] ^ ROL64(bc[(i + 1) % 5], 1);
      for (int j = 0; j < 25; j += 5) st[j + i] ^= t;
    }
    t = st[1];
    for (int i = 0; i < 24; i++) {
      int j = PILN[i];
      bc[0] = st[j];
      st[j] = ROL64(t, ROTC[i]);
      t = bc[0];
    }
    for (int j = 0; j < 25; j += 5) {
      for (int i = 0; i < 5; i++) bc[i] = st[j + i];
      for (int i = 0; i < 5; i++) st[j + i] ^= (~bc[(i + 1) % 5]) & bc[(i + 2) % 5];
    }
    st[0] ^= RC[round];
  }
}

// ---------------------------------------------------------------------------
// cSHAKE256 (N = "", S = custom)
// ---------------------------------------------------------------------------

static void store64_le(uint8_t *p, uint64_t v) {
  for (int i = 0; i < 8; i++) p[i] = (v >> (8 * i)) & 0xff;
}

static void xor_block(uint64_t st[25], const uint8_t *block, size_t len) {
  uint8_t *sb = (uint8_t *)st;
  for (size_t i = 0; i < len; i++) sb[i] ^= block[i];
}

// Absorb the final message piece with cSHAKE domain padding (0x04) and permute.
static void keccak_absorb_final(uint64_t st[25], const uint8_t *data, size_t len) {
  while (len >= RATE) {
    xor_block(st, data, RATE);
    keccakf(st);
    data += RATE;
    len -= RATE;
  }
  uint8_t block[RATE];
  memset(block, 0, RATE);
  memcpy(block, data, len);
  block[len] ^= 0x04;
  block[RATE - 1] ^= 0x80;
  xor_block(st, block, RATE);
  keccakf(st);
}

static void keccak_squeeze(uint64_t st[25], uint8_t *out, size_t outlen) {
  size_t made = 0;
  while (made < outlen) {
    size_t chunk = outlen - made;
    if (chunk > RATE) chunk = RATE;
    memcpy(out + made, (uint8_t *)st, chunk);
    made += chunk;
    if (made < outlen) keccakf(st);
  }
}

static size_t left_encode(uint8_t *out, size_t x) {
  uint8_t tmp[8];
  size_t n = 0;
  while (x > 0) { tmp[n++] = x & 0xff; x >>= 8; }
  if (n == 0) { out[0] = 1; out[1] = 0; return 2; }
  out[0] = n;
  for (size_t i = 0; i < n; i++) out[1 + i] = tmp[n - 1 - i];
  return n + 1;
}

// State after absorbing bytepad(encode_string("") || encode_string(custom), RATE).
// This is one full block, absorbed WITHOUT extra padding (per NIST SP 800-185).
static void cshake_init(uint64_t st[25], const char *custom) {
  memset(st, 0, 25 * sizeof(uint64_t));
  uint8_t prefix[RATE];
  memset(prefix, 0, RATE);
  size_t p = 0;
  p += left_encode(prefix + p, RATE);
  p += left_encode(prefix + p, 0);
  size_t clen = strlen(custom);
  p += left_encode(prefix + p, clen * 8);
  memcpy(prefix + p, custom, clen);
  xor_block(st, prefix, RATE);
  keccakf(st);
}

static void cshake256(const uint8_t *data, size_t datalen, const char *custom, uint8_t *out, size_t outlen) {
  uint64_t st[25];
  cshake_init(st, custom);
  keccak_absorb_final(st, data, datalen);
  keccak_squeeze(st, out, outlen);
}

// Precomputed post-prefix states: saves one Keccak permutation per cSHAKE call.
static uint64_t st_pow0[25];
static uint64_t st_heavy0[25];

static void cshake_fast(const uint64_t st0[25], const uint8_t *data, size_t datalen, uint8_t out[32]) {
  uint64_t st[25];
  memcpy(st, st0, sizeof(st));
  keccak_absorb_final(st, data, datalen);  // datalen <= 48 here: one block
  memcpy(out, (uint8_t *)st, 32);
}

// ---------------------------------------------------------------------------
// kHeavyHash
// ---------------------------------------------------------------------------

// Digital nibble engine: p[i] = sum_j M[i][j] * v[j], v[j] and M[i][j] in 0..15.
static void matvec_digital(const uint8_t v[64], uint16_t p[64]) {
  cpu_native_matvec++;
  for (int i = 0; i < 64; i++) {
    uint32_t s = 0;
    for (int jj = 0; jj < 32; jj++) {
      uint8_t b = mnib[i][jj];
      s += (uint32_t)(b & 0x0f) * v[2 * jj] + (uint32_t)(b >> 4) * v[2 * jj + 1];
    }
    p[i] = (uint16_t)s;
  }
}

// ---- Optical nibble engine ------------------------------------------------

static void optical_raw(const uint8_t v[8], const uint8_t w[8], uint16_t raw[8]) {
  uint32_t t0 = micros();
  clear_optics();
  leds(false, false);
  delayMicroseconds(opt_discharge_us);
  leds(true, true);  // both LEDs on; the ITO plate pixels gate/attenuate per lane
  for (int s = 0; s < 15; s++) {
    for (int k = 0; k < 8; k++) analogWrite(ITO_PINS[k], s < w[k] ? v[k] * 17 : 0);
    delayMicroseconds(opt_slot_us);
  }
  leds(false, false);
  clear_optics();  // light off before readout: the detector holds its integrated value
  opt_wait_us += (uint32_t)(micros() - t0);
  for (int k = 0; k < 8; k++) raw[k] = sample_pd(k);
}

static bool optical_calibrate() {
  clear_optics();
  delayMicroseconds(opt_discharge_us);
  for (int k = 0; k < NUM_PD; k++) {
    uint32_t sum = 0;
    for (int n = 0; n < 4; n++) sum += sample_pd(k);
    opt_dark[k] = sum / 4;
  }
  uint8_t full[8];
  for (int k = 0; k < 8; k++) full[k] = 15;
  uint16_t raw[8];
  optical_raw(full, full, raw);
  opt_cal_ok = true;
  for (int k = 0; k < NUM_PD; k++) {
    opt_full[k] = raw[k];
    if (raw[k] < opt_dark[k] + 100) opt_cal_ok = false;  // not enough optical swing
  }
  ex_note(ex_cal, opt_cal_ok);
  return opt_cal_ok;
}

// Converts a photodiode reading to an estimated product 0..225.
static inline uint16_t optical_to_product(int k, uint16_t raw) {
  int32_t num = (int32_t)raw - (int32_t)opt_dark[k];
  int32_t den = (int32_t)opt_full[k] - (int32_t)opt_dark[k];
  if (den <= 0 || num <= 0) return 0;
  int32_t est = (num * 225 + den / 2) / den;
  return (uint16_t)(est > 225 ? 225 : est);
}

static void matvec_optical(const uint8_t v[64], uint16_t p[64]) {
  for (int i = 0; i < 64; i++) {
    yield();
    uint32_t sum = 0;
    for (int b = 0; b < 8; b++) {
      uint8_t vv[8], ww[8];
      uint16_t raw[8];
      for (int k = 0; k < 8; k++) { vv[k] = v[8 * b + k]; ww[k] = mget(i, 8 * b + k); }
      optical_raw(vv, ww, raw);
      bool tile_ok = true;
      for (int k = 0; k < 8; k++) {
        uint16_t est = optical_to_product(k, raw[k]);
        uint16_t exact = (uint16_t)(vv[k] * ww[k]);
        sum += est;
        bool ok = (est == exact);
        ex_note(ex_prod, ok);
        if (!ok) { tile_ok = false; ex_fail_log("nibble", (uint32_t)(i * 8 + b), k, est, exact); }
      }
      ex_note(ex_tile, tile_ok);
    }
    p[i] = (uint16_t)sum;
  }
}

// ---- Gate engine ----------------------------------------------------------
// Programs are netlists of two-input gates compiled by kaspa_gatec.py. One optical gate evaluation:
//   LED A pulses while ITO pixel k shows input a, then LED B pulses while pixel k shows input b;
//   photodiode k integrates s = a + b; the CPU thresholds s into 0/1/2 and the gate's truth table
//   gives the output bit. Eight gates (lanes) evaluate per wave.

static bool gate_optical = true;
static bool gate_cal_ok = false;
static bool shadow = true;   // CPU also computes the ideal output of every gate (stats, trust 0). SHADOW 0: optics only
static uint16_t gate_dark[8], gate_full2[8];
static uint64_t gate_waves_run = 0, gate_decisions = 0, gate_wrong = 0;
static bool chain_hit = false;

#if HAVE_GATES
static uint32_t gw[(GW_BITS + 31) / 32 + 1];
static const uint8_t GATE_TT[6][3] = {{0,0,1},{0,1,1},{0,1,0},{1,1,0},{1,0,0},{1,0,1}};

static inline uint8_t gbit(uint32_t w) { return (gw[w >> 5] >> (w & 31)) & 1; }
static inline void gset(uint32_t w, uint8_t v) {
  if (v) gw[w >> 5] |= (1u << (w & 31)); else gw[w >> 5] &= ~(1u << (w & 31));
}

static void gprog_begin(const GProg &P) {
  uint32_t words = ((P.first_wire + P.n_gates) >> 5) + 1;
  memset(gw, 0, words * sizeof(uint32_t));
  gset(1, 1);  // constant-1 wire
  cpu_glue_ops += words;
}

static void gprog_exec_digital(const GProg &P) {
  for (uint32_t g = 0; g < P.n_gates; g++) {
    if ((g & 0x3fff) == 0) yield();
    uint32_t w0 = P.gates[2 * g];
    uint8_t op = w0 >> 28;
    uint8_t cls = gbit(w0 & 0x0fffffff) + gbit(P.gates[2 * g + 1]);
    gset(P.first_wire + g, GATE_TT[op][cls]);
  }
  cpu_native_gates += P.n_gates;  // here the CPU, not the optics, evaluated the logic
}

// One optical wave: n<=8 gates, lane k <-> ITO pixel k / photodiode k.
static void gate_wave_optical(const uint8_t a[8], const uint8_t b[8], int n, uint8_t cls[8]) {
  uint32_t t0 = micros();
  clear_optics();
  leds(false, false);
  delayMicroseconds(opt_discharge_us);
  for (int k = 0; k < 8; k++) { analogWrite(ITO_PINS[k], a[k] ? 255 : 0); TR("ITO", "show_a", k, a[k]); }
  leds(true, false);  TR("LED_A", "on", 0, 0);
  delayMicroseconds(opt_slot_us);
  leds(false, false); TR("LED_A", "off", 0, 0);
  for (int k = 0; k < 8; k++) { analogWrite(ITO_PINS[k], b[k] ? 255 : 0); TR("ITO", "show_b", k, b[k]); }
  leds(false, true);  TR("LED_B", "on", 0, 0);
  delayMicroseconds(opt_slot_us);
  leds(false, false); TR("LED_B", "off", 0, 0);
  clear_optics();  // detector holds the integrated value
  opt_wait_us += (uint32_t)(micros() - t0);
  for (int k = 0; k < n; k++) {
    int32_t raw = sample_pd(k);
    int32_t den = (int32_t)gate_full2[k] - (int32_t)gate_dark[k];
    int32_t q = den > 0 ? ((raw - (int32_t)gate_dark[k]) * 4) / den : 0;  // quarters of full scale
    cls[k] = q < 1 ? 0 : (q < 3 ? 1 : 2);                                  // s = 0 / 1 / 2
    TR("CPU", "threshold", k, cls[k]);
  }
}

static bool gate_calibrate() {
  clear_optics();
  leds(false, false);
  delayMicroseconds(opt_discharge_us);
  for (int k = 0; k < 8; k++) {
    uint32_t sum = 0;
    for (int n = 0; n < 4; n++) sum += sample_pd(k);
    gate_dark[k] = sum / 4;
  }
  // Full scale: every pixel open and both LEDs lit for both slots (s = 2).
  clear_optics();
  delayMicroseconds(opt_discharge_us);
  for (int k = 0; k < 8; k++) analogWrite(ITO_PINS[k], 255);
  leds(true, true);
  delayMicroseconds(opt_slot_us * 2);
  leds(false, false);
  clear_optics();
  gate_cal_ok = true;
  for (int k = 0; k < 8; k++) {
    gate_full2[k] = sample_pd(k);
    if (gate_full2[k] < gate_dark[k] + 100) gate_cal_ok = false;  // not enough optical swing
  }
  ex_note(ex_cal, gate_cal_ok);
  return gate_cal_ok;
}

static void gprog_exec_optical(const GProg &P) {
  uint32_t g = 0;
  uint64_t wrong0 = gate_wrong;
  bool use_optical = opt_trust || !shadow;  // without a shadow there is no ideal value to fall back on
  for (uint32_t wv = 0; wv < P.n_waves; wv++) {
    uint32_t end = P.wave_end[wv];
    int n = (int)(end - g);
    uint8_t a[8] = {0}, b[8] = {0}, cls[8] = {0}, op[8];
    for (int k = 0; k < n; k++) {
      uint32_t w0 = P.gates[2 * (g + k)];
      op[k] = w0 >> 28;
      a[k] = gbit(w0 & 0x0fffffff);
      b[k] = gbit(P.gates[2 * (g + k) + 1]);
    }
    gate_wave_optical(a, b, n, cls);
    gate_waves_run++;
    opt_gate_evals += n;
    cpu_readout_ops += n;
    if ((wv & 0x3f) == 0) yield();
    bool wave_ok = true;
    for (int k = 0; k < n; k++) {
      uint8_t optical = GATE_TT[op[k]][cls[k]];
      uint8_t value = optical;
      if (shadow) {
        uint8_t ideal = GATE_TT[op[k]][a[k] + b[k]];
        gate_decisions++;
        bool ok = (optical == ideal);
        ex_note(ex_gate, ok);
        if (!ok) { gate_wrong++; wave_ok = false; ex_fail_log("gate", wv, k, optical, ideal); }
        if (!use_optical) value = ideal;
      }
      gset(P.first_wire + g + k, value);
    }
    if (shadow) ex_note(ex_wave, wave_ok);
    g = end;
  }
  if (shadow) ex_note(ex_eval, gate_wrong == wrong0);
}

static void gprog_exec(const GProg &P) {
  if (gate_optical && gate_cal_ok) gprog_exec_optical(P);
  else gprog_exec_digital(P);
}

static const GProg PROG_HEAVY = {GP_GATES, GP_WAVE_END, GP_OUT, GP_N_GATES, GP_N_WAVES, 256, 256, GP_FIRST_GATE_WIRE};

static bool gates_job_ok() {
  if (memcmp(GP_PREPOW, pre_pow, 32) != 0) return false;
  uint32_t h = 2166136261u;
  for (int i = 0; i < 64; i++)
    for (int j = 0; j < 64; j++) h = (h ^ mget(i, j)) * 16777619u;
  return h == GP_MATRIX_FNV;
}

// Heavy stage: pow_hash bytes -> transformed bytes, entirely as gates.
static void gates_run(const uint8_t pow_hash[32], uint8_t out[32]) {
  TR("PROG", "heavy", (int)GP_N_GATES, (int)GP_N_WAVES);
  gprog_begin(PROG_HEAVY);
  for (int i = 0; i < 32; i++)
    for (int k = 0; k < 8; k++) gset(2 + 8 * i + k, (pow_hash[i] >> k) & 1);
  cpu_glue_ops += 256;
  TR("CPU", "load_inputs", 256, 0);
  gprog_exec(PROG_HEAVY);
  for (int i = 0; i < 32; i++) {
    uint8_t b = 0;
    for (int k = 0; k < 8; k++) b |= gbit(GP_OUT[8 * i + k]) << k;
    out[i] = b;
  }
  cpu_glue_ops += 256;
  TR("CPU", "read_outputs", 256, 0);
}

static void gate_test() {
  int att = 0;
  if (!matrix_loaded && !generate_matrix(1000, &att)) { Serial.println(F("ERR,MATRIX_GEN")); return; }
  if (!gates_job_ok()) { Serial.println(F("ERR,GATE_PROGRAM_JOB_MISMATCH")); return; }
  if (gate_optical && !gate_calibrate()) { Serial.println(F("ERR,GATE_CAL_LOW_SWING")); return; }
  uint8_t pw[32], v[64], got[32], want[32];
  for (int i = 0; i < 32; i++) pw[i] = (uint8_t)(i * 37 + 11);
  for (int i = 0; i < 32; i++) { v[2*i] = pw[i] >> 4; v[2*i+1] = pw[i] & 15; }
  uint16_t p[64];
  matvec_digital(v, p);
  for (int i = 0; i < 32; i++)
    want[i] = pw[i] ^ (uint8_t)((((p[2*i] >> 10) & 15) << 4) | ((p[2*i+1] >> 10) & 15));
  uint64_t wrong0 = gate_wrong, dec0 = gate_decisions;
  uint32_t t0 = millis();
  gates_run(pw, got);
  uint32_t ms = millis() - t0;
  Serial.print(F("OK,GATETEST,match=")); Serial.print(memcmp(got, want, 32) == 0 ? 1 : 0);
  Serial.print(F(",gates=")); Serial.print((unsigned)GP_N_GATES);
  Serial.print(F(",waves=")); Serial.print((unsigned)GP_N_WAVES);
  Serial.print(F(",wrong_gate_decisions=")); print_u64_dec(gate_wrong - wrong0);
  Serial.print(F(",decisions=")); print_u64_dec(gate_decisions - dec0);
  Serial.print(F(",ms=")); Serial.println(ms);
}
#endif

#if HAVE_CHAIN
static const GProg PROG_ROUND = {RP_GATES, RP_WAVE_END, RP_OUT, RP_N_GATES, RP_N_WAVES, RP_N_IN, RP_N_OUT, RP_FIRST_GATE_WIRE};
static const GProg PROG_CMP = {CP_GATES, CP_WAVE_END, CP_OUT, CP_N_GATES, CP_N_WAVES, CP_N_IN, CP_N_OUT, CP_FIRST_GATE_WIRE};

// Keccak-f[1600] as 24 runs of the round program. The CPU only moves bits in and out.
static void keccak_optical(uint64_t st[25]) {
  for (int r = 0; r < 24; r++) {
    TR("PROG", "round", r, (int)RP_N_WAVES);
    gprog_begin(PROG_ROUND);
    for (int L = 0; L < 25; L++)
      for (int bit = 0; bit < 64; bit++) gset(2 + L * 64 + bit, (st[L] >> bit) & 1);
    for (int i = 0; i < 64; i++) gset(2 + 1600 + i, (RC[r] >> i) & 1);
    cpu_glue_ops += 1664;
    TR("CPU", "load_state_and_rc", 1664, 0);
    gprog_exec(PROG_ROUND);
    for (int L = 0; L < 25; L++) {
      uint64_t lane = 0;
      for (int bit = 0; bit < 64; bit++) lane |= (uint64_t)gbit(RP_OUT[L * 64 + bit]) << bit;
      st[L] = lane;
    }
    cpu_glue_ops += 1600;
    TR("CPU", "read_state", 1600, 0);
    yield();
  }
}

// Whole hash with the logic done by gate programs. CPU work: XOR constants/nonce into the absorb
// state (data prep), move bits to and from the programs, read the single hit bit.
static void chain_hash(uint64_t nonce, uint8_t final_hash[32]) {
  uint64_t st[25];
  uint8_t blk[RATE];

  memcpy(st, st_pow0, sizeof(st));
  memset(blk, 0, RATE);
  memcpy(blk, pre_pow, 32);
  store64_le(blk + 32, timestamp);
  store64_le(blk + 40, nonce);
  blk[48] ^= 0x04;
  blk[RATE - 1] ^= 0x80;
  xor_block(st, blk, RATE);
  cpu_glue_ops += RATE;
  TR("CPU", "glue_absorb_pow", RATE, 0);
  keccak_optical(st);

  uint8_t pw[32], tf[32];
  memcpy(pw, (uint8_t *)st, 32);
  gates_run(pw, tf);

  memcpy(st, st_heavy0, sizeof(st));
  memset(blk, 0, RATE);
  memcpy(blk, tf, 32);
  blk[32] ^= 0x04;
  blk[RATE - 1] ^= 0x80;
  xor_block(st, blk, RATE);
  cpu_glue_ops += RATE;
  TR("CPU", "glue_absorb_heavy", RATE, 0);
  keccak_optical(st);

  uint8_t raw[32];
  memcpy(raw, (uint8_t *)st, 32);
  TR("PROG", "cmp", (int)CP_N_GATES, (int)CP_N_WAVES);
  gprog_begin(PROG_CMP);
  for (int i = 0; i < 32; i++)
    for (int k = 0; k < 8; k++) gset(2 + 8 * i + k, (raw[i] >> k) & 1);
  cpu_glue_ops += 256;
  gprog_exec(PROG_CMP);
  chain_hit = gbit(CP_OUT[0]) != 0;
  TR("CPU", "read_hit_bit", chain_hit, 0);
  for (int i = 0; i < 32; i++) final_hash[i] = raw[31 - i];  // reported hash is byte-reversed
}
#endif

static void heavy_transform_with(Engine eng, const uint8_t pow_hash[32], uint8_t out[32]) {
#if HAVE_GATES
  if (eng == ENG_GATES) { gates_run(pow_hash, out); return; }
#endif
  uint8_t v[64];
  uint16_t p[64];
  for (int i = 0; i < 32; i++) {
    v[2 * i] = pow_hash[i] >> 4;
    v[2 * i + 1] = pow_hash[i] & 0x0f;
  }

  bool use_opt = (eng == ENG_OPTICAL) && opt_cal_ok && (mix_forced || ((opt_counter++ % opt_every) == 0));
  if (use_opt) {
    matvec_optical(v, p);
    opt_hashes++;
    if (!opt_trust) {  // cross-check: digital result is authoritative
      uint16_t d[64];
      matvec_digital(v, d);
      bool bad = false;
      for (int i = 0; i < 64; i++) if (((p[i] >> 10) & 0x0f) != ((d[i] >> 10) & 0x0f)) bad = true;
      if (bad) opt_mismatch++;
      ex_note(ex_eval, !bad);
      memcpy(p, d, sizeof(p));
    }
  } else {
    matvec_digital(v, p);
  }

  for (int i = 0; i < 32; i++) {
    uint8_t prod = (uint8_t)((((p[2 * i] >> 10) & 0x0f) << 4) | ((p[2 * i + 1] >> 10) & 0x0f));
    out[i] = pow_hash[i] ^ prod;
  }
}

static Engine mix_pick() {
  mix_counter++;
#if HAVE_GATES
  if (mix_gate_every && (mix_counter % mix_gate_every) == 0) return ENG_GATES;
#endif
  if (mix_nib_every && (mix_counter % mix_nib_every) == 0) return ENG_OPTICAL;
  return ENG_DIGITAL;
}

static void heavy_transform(const uint8_t pow_hash[32], uint8_t out[32]) {
  Engine eng = (engine == ENG_MIX) ? mix_pick() : engine;
  mix_forced = (engine == ENG_MIX);
  uint32_t t0 = micros();
  heavy_transform_with(eng, pow_hash, out);
  int idx = (eng == ENG_GATES) ? 2 : (eng == ENG_OPTICAL ? 1 : 0);
  eng_hashes[idx]++;
  eng_us[idx] += (uint32_t)(micros() - t0);
}

static void kheavy_hash(uint64_t nonce, uint8_t final_hash[32]) {
#if HAVE_CHAIN
  if (engine == ENG_CHAIN) { chain_hash(nonce, final_hash); return; }
#endif
  uint8_t work[48], pow_hash[32], transformed[32];
  memcpy(work, pre_pow, 32);
  store64_le(work + 32, timestamp);
  store64_le(work + 40, nonce);
  cshake_fast(st_pow0, work, 48, pow_hash);
  heavy_transform(pow_hash, transformed);
  cshake_fast(st_heavy0, transformed, 32, final_hash);
  for (int i = 0; i < 16; i++) {  // Kaspa compares the byte-reversed hash
    uint8_t t = final_hash[i];
    final_hash[i] = final_hash[31 - i];
    final_hash[31 - i] = t;
  }
}

static bool hash_meets_target(const uint8_t h[32]) {
  for (int i = 0; i < 32; i++) {
    if (h[i] < target[i]) return true;
    if (h[i] > target[i]) return false;
  }
  return true;
}

// ---------------------------------------------------------------------------
// Matrix generation (same scheme as the Python bench) + GF(2) rank
// ---------------------------------------------------------------------------

static int gf2_rank_64() {
  uint64_t rows[64];
  for (int i = 0; i < 64; i++) {
    uint64_t v = 0;
    for (int j = 0; j < 64; j++) if (matrix[i][j] & 1) v |= (1ULL << j);
    rows[i] = v;
  }
  int rank = 0;
  for (int col = 0; col < 64; col++) {
    int pivot = -1;
    for (int r = rank; r < 64; r++) if ((rows[r] >> col) & 1) { pivot = r; break; }
    if (pivot < 0) continue;
    uint64_t tmp = rows[rank]; rows[rank] = rows[pivot]; rows[pivot] = tmp;
    for (int r = 0; r < 64; r++) if (r != rank && ((rows[r] >> col) & 1)) rows[r] ^= rows[rank];
    rank++;
  }
  return rank;
}

// cSHAKE256(seed || attempt_le32, "KaspaBenchMatrix"), 4096-byte stream, low nibbles.
static bool generate_matrix(int max_attempts, int *attempts_used) {
  for (int attempt = 0; attempt < max_attempts; attempt++) {
    uint8_t seed[36];
    memcpy(seed, pre_pow, 32);
    seed[32] = attempt & 0xff;
    seed[33] = (attempt >> 8) & 0xff;
    seed[34] = (attempt >> 16) & 0xff;
    seed[35] = (attempt >> 24) & 0xff;

    uint64_t st[25];
    cshake_init(st, "KaspaBenchMatrix");
    keccak_absorb_final(st, seed, 36);

    int pos = 0;
    for (int i = 0; i < 64; i++) {
      for (int j = 0; j < 64; j++) {
        if (pos == RATE) { keccakf(st); pos = 0; }
        matrix[i][j] = ((uint8_t *)st)[pos++] & 0x0f;
      }
    }
    if (gf2_rank_64() == 64) {
      pack_matrix();
      matrix_loaded = true;
      if (attempts_used) *attempts_used = attempt + 1;
      return true;
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// Independent verifier: second Keccak with constants derived from the spec
// (LFSR round constants, rho offsets from the (x,y) walk), lane-wise state,
// separate cSHAKE padding and a plain matrix-vector product.
// ---------------------------------------------------------------------------

static uint64_t ref_rc[24];
static int ref_rho[25];

static inline uint64_t ref_rotl(uint64_t x, int n) { n &= 63; return n ? ((x << n) | (x >> (64 - n))) : x; }

static bool ref_lfsr_bit(int t) {
  uint16_t R = 1;
  for (int i = 1; i <= t % 255; i++) {
    R <<= 1;
    if (R & 0x100) R ^= 0x171;
  }
  return R & 1;
}

static void ref_init() {
  for (int i = 0; i < 24; i++) {
    uint64_t c = 0;
    for (int j = 0; j < 7; j++) if (ref_lfsr_bit(j + 7 * i)) c |= (1ULL << ((1 << j) - 1));
    ref_rc[i] = c;
  }
  for (int i = 0; i < 25; i++) ref_rho[i] = 0;
  int x = 1, y = 0;
  for (int t = 0; t < 24; t++) {
    ref_rho[x + 5 * y] = ((t + 1) * (t + 2) / 2) % 64;
    int nx = y, ny = (2 * x + 3 * y) % 5;
    x = nx; y = ny;
  }
}

static void ref_keccakf(uint64_t A[25]) {
  uint64_t B[25], C[5], D[5];
  for (int r = 0; r < 24; r++) {
    for (int x = 0; x < 5; x++) C[x] = A[x] ^ A[x + 5] ^ A[x + 10] ^ A[x + 15] ^ A[x + 20];
    for (int x = 0; x < 5; x++) D[x] = C[(x + 4) % 5] ^ ref_rotl(C[(x + 1) % 5], 1);
    for (int i = 0; i < 25; i++) A[i] ^= D[i % 5];
    for (int x = 0; x < 5; x++)
      for (int y = 0; y < 5; y++)
        B[y + 5 * ((2 * x + 3 * y) % 5)] = ref_rotl(A[x + 5 * y], ref_rho[x + 5 * y]);
    for (int x = 0; x < 5; x++)
      for (int y = 0; y < 5; y++)
        A[x + 5 * y] = B[x + 5 * y] ^ ((~B[(x + 1) % 5 + 5 * y]) & B[(x + 2) % 5 + 5 * y]);
    A[0] ^= ref_rc[r];
  }
}

static uint64_t ref_load64(const uint8_t *p) {
  uint64_t v = 0;
  for (int i = 0; i < 8; i++) v |= (uint64_t)p[i] << (8 * i);
  return v;
}

// out: 32 bytes. datalen <= 80.
static void ref_cshake256_32(const uint8_t *data, size_t datalen, const char *custom, uint8_t out[32]) {
  uint8_t msg[RATE * 2 + 8];
  memset(msg, 0, sizeof(msg));
  size_t clen = strlen(custom), p = 0;
  msg[p++] = 1; msg[p++] = RATE;                       // left_encode(136)
  msg[p++] = 1; msg[p++] = 0;                          // encode_string("")
  msg[p++] = 1; msg[p++] = (uint8_t)(clen * 8);        // left_encode(bits), clen*8 < 256
  memcpy(msg + p, custom, clen);
  size_t L = RATE + datalen;                           // prefix is exactly one block
  memcpy(msg + RATE, data, datalen);
  size_t padded = ((L / RATE) + 1) * RATE;
  msg[L] ^= 0x04;
  msg[padded - 1] ^= 0x80;

  uint64_t A[25];
  memset(A, 0, sizeof(A));
  for (size_t off = 0; off < padded; off += RATE) {
    for (int i = 0; i < RATE / 8; i++) A[i] ^= ref_load64(msg + off + 8 * i);
    ref_keccakf(A);
  }
  for (int i = 0; i < 4; i++) store64_le(out + 8 * i, A[i]);
}

static void ref_kheavy_hash(uint64_t nonce, uint8_t out[32]) {
  cpu_ref_verifies++;
  uint8_t work[48], pow_hash[32], transformed[32], fin[32];
  memcpy(work, pre_pow, 32);
  for (int i = 0; i < 8; i++) work[32 + i] = (timestamp >> (8 * i)) & 0xff;
  for (int i = 0; i < 8; i++) work[40 + i] = (nonce >> (8 * i)) & 0xff;
  ref_cshake256_32(work, 48, "ProofOfWorkHash", pow_hash);

  uint32_t prod[64];
  for (int i = 0; i < 64; i++) {
    uint32_t s = 0;
    for (int j = 0; j < 64; j++) {
      uint32_t v = (j & 1) ? (pow_hash[j / 2] & 0x0f) : (pow_hash[j / 2] >> 4);
      s += (uint32_t)matrix[i][j] * v;
    }
    prod[i] = s >> 10;
  }
  for (int i = 0; i < 32; i++)
    transformed[i] = pow_hash[i] ^ (uint8_t)(((prod[2 * i] & 0xf) << 4) | (prod[2 * i + 1] & 0xf));

  ref_cshake256_32(transformed, 32, "HeavyHash", fin);
  for (int i = 0; i < 32; i++) out[i] = fin[31 - i];
}

// ---------------------------------------------------------------------------
// Hex / print helpers
// ---------------------------------------------------------------------------

static int hexval(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

static bool hex_to_bytes(const char *s, uint8_t *out, size_t n) {
  if (!s || strlen(s) != n * 2) return false;
  for (size_t i = 0; i < n; i++) {
    int hi = hexval(s[2 * i]), lo = hexval(s[2 * i + 1]);
    if (hi < 0 || lo < 0) return false;
    out[i] = (uint8_t)((hi << 4) | lo);
  }
  return true;
}

static uint64_t parse_hex64(const char *s) {
  uint64_t v = 0;
  for (int i = 0; s && s[i] && i < 16; i++) {
    int h = hexval(s[i]);
    if (h < 0) break;
    v = (v << 4) | (uint64_t)h;
  }
  return v;
}

static uint64_t parse_u64(const char *s) {  // decimal, or 0x-prefixed hex
  if (!s) return 0;
  if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) return parse_hex64(s + 2);
  uint64_t v = 0;
  while (*s >= '0' && *s <= '9') v = v * 10 + (uint64_t)(*s++ - '0');
  return v;
}

static void print_hex64(uint64_t v) {
  for (int i = 15; i >= 0; i--) {
    uint8_t nib = (v >> (i * 4)) & 0xF;
    Serial.print((char)(nib < 10 ? '0' + nib : 'a' + nib - 10));
  }
}

static void print_hex_bytes(const uint8_t *b, size_t n) {
  for (size_t i = 0; i < n; i++) {
    if (b[i] < 16) Serial.print('0');
    Serial.print(b[i], HEX);
  }
}

static void print_u64_dec(uint64_t v) {
  char buf[24];
  int n = 0;
  if (v == 0) buf[n++] = '0';
  while (v > 0) { buf[n++] = '0' + (int)(v % 10); v /= 10; }
  while (n > 0) Serial.print(buf[--n]);
}

// ---------------------------------------------------------------------------
// Job helpers (formerly PC side)
// ---------------------------------------------------------------------------

static void target_from_leading_zero_bits(int bits) {
  if (bits < 1) bits = 1;
  if (bits > 255) bits = 255;
  for (int i = 0; i < 32; i++) {
    int lo = i * 8;
    if (bits >= lo + 8) target[i] = 0x00;
    else if (bits <= lo) target[i] = 0xff;
    else target[i] = 0xff >> (bits - lo);
  }
}

static void load_demo_template() {
  const char *d = "kaspa-optical-bench-demo-template";
  cshake256((const uint8_t *)d, strlen(d), "ProofOfWorkHash", pre_pow, 32);
}

static void init_hash_states() {
  cshake_init(st_pow0, "ProofOfWorkHash");
  cshake_init(st_heavy0, "HeavyHash");
  ref_init();
}

// ---------------------------------------------------------------------------
// Telemetry
// ---------------------------------------------------------------------------

static void read_telemetry(uint16_t *vals, int *n) {
  if (source == SRC_CAMERA) {
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++) vals[y * 8 + x] = sample_pd(x) >> 2;
    *n = 64;
  } else if (source == SRC_PHOTODIODES) {
    for (int i = 0; i < NUM_PD; i++) vals[i] = sample_pd(i);
    *n = NUM_PD;
  } else {
    *n = 0;
  }
}

static void send_sample() {
  uint16_t v[64];
  int n;
  read_telemetry(v, &n);
  if (n == 0) { Serial.println(F("ERR,SOURCE_NONE")); return; }
  Serial.print(source == SRC_CAMERA ? F("F,") : F("D,"));
  Serial.print(millis());
  for (int i = 0; i < n; i++) { Serial.print(','); Serial.print(v[i]); }
  Serial.println();
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------

// Returns 1 found, 0 exhausted, -1 stopped by user. *tried = nonces hashed.
static int search(uint64_t first, uint64_t count, uint64_t *found_nonce, uint8_t found_hash[32], uint64_t *tried, bool interactive) {
  uint8_t h[32];
  *tried = 0;
  for (uint64_t k = 0; k < count; k++) {
    uint64_t nonce = first + k;
    kheavy_hash(nonce, h);
    (*tried)++;
    if ((k & 0x3f) == 0) yield();

    if ((engine == ENG_DIGITAL || engine == ENG_MIX) && ito_every && (k % ito_every) == 0) update_optics(h);

    if (engine == ENG_CHAIN ? chain_hit : hash_meets_target(h)) {
      *found_nonce = nonce;
      memcpy(found_hash, h, 32);
      update_optics(h);
      return 1;
    }

    if (interactive && (engine != ENG_DIGITAL || (k % batch_size) == (batch_size - 1))) {
      if (Serial.available()) {
        while (Serial.available()) Serial.read();
        return -1;
      }
    }
  }
  return 0;
}

static void report_json(bool solved, uint64_t nonce, const uint8_t *hash, bool verified,
                        uint64_t tried, float elapsed_s, const uint8_t *ito,
                        const uint16_t *tel, int tel_n, int matrix_attempts) {
  Serial.print(F("REPORT,{\"solved\":")); Serial.print(solved ? F("true") : F("false"));
  Serial.print(F(",\"nonces_attempted\":")); print_u64_dec(tried);
  Serial.print(F(",\"elapsed_s\":")); Serial.print(elapsed_s, 3);
  Serial.print(F(",\"bench_hashrate_approx\":")); Serial.print(elapsed_s > 0 ? (float)tried / elapsed_s : 0.0f, 1);
  Serial.print(F(",\"source\":\""));
  Serial.print(source == SRC_CAMERA ? F("camera") : source == SRC_PHOTODIODES ? F("photodiodes") : F("none"));
  Serial.print(F("\",\"timestamp\":")); print_u64_dec(timestamp);
  Serial.print(F(",\"pre_pow_hash_hex\":\"")); print_hex_bytes(pre_pow, 32);
  Serial.print(F("\",\"target_hex\":\"")); print_hex_bytes(target, 32);
  Serial.print(F("\",\"matrix_attempts\":")); Serial.print(matrix_attempts);
  Serial.print(F(",\"engine\":\"")); Serial.print(engine == ENG_CHAIN ? (gate_optical ? F("chain_optical") : F("chain_digital")) : engine == ENG_MIX ? F("mix") : engine == ENG_GATES ? (gate_optical ? F("gates_optical") : F("gates_digital")) : engine == ENG_OPTICAL ? F("optical") : F("digital"));
  Serial.print('"');
  if (engine == ENG_OPTICAL) {
    Serial.print(F(",\"optical_trust\":")); Serial.print(opt_trust ? F("true") : F("false"));
    Serial.print(F(",\"optical_hashes\":")); print_u64_dec(opt_hashes);
    Serial.print(F(",\"optical_nibble_mismatch_hashes\":")); print_u64_dec(opt_mismatch);
  }
  if (engine == ENG_GATES) {
    Serial.print(F(",\"gate_decisions\":")); print_u64_dec(gate_decisions);
    Serial.print(F(",\"gate_wrong_decisions\":")); print_u64_dec(gate_wrong);
  }
  if (engine == ENG_MIX) {
    Serial.print(F(",\"mix\":{\"nibble_every\":")); Serial.print((unsigned)mix_nib_every);
    Serial.print(F(",\"gate_every\":")); Serial.print((unsigned)mix_gate_every);
    const char *names[3] = {"digital", "nibble_optical", "gates"};
    for (int i = 0; i < 3; i++) {
      Serial.print(",\""); Serial.print(names[i]); Serial.print("\":{\"hashes\":"); print_u64_dec(eng_hashes[i]);
      Serial.print(",\"ms\":"); print_u64_dec(eng_us[i] / 1000); Serial.print('}');
    }
    Serial.print('}');
    if (engine == ENG_MIX && gate_decisions) {
      Serial.print(F(",\"gate_decisions\":")); print_u64_dec(gate_decisions);
      Serial.print(F(",\"gate_wrong_decisions\":")); print_u64_dec(gate_wrong);
    }
  }
  if (opt_false_hits) { Serial.print(F(",\"false_hits_discarded\":")); print_u64_dec(opt_false_hits); }
  ex_json();
  cpu_json();
  if (solved) {
    Serial.print(F(",\"solution\":{\"nonce\":")); print_u64_dec(nonce);
    Serial.print(F(",\"nonce_hex\":\"")); print_hex64(nonce);
    Serial.print(F("\",\"hash_hex\":\"")); print_hex_bytes(hash, 32);
    Serial.print(F("\",\"verified_by_independent_check\":")); Serial.print(verified ? F("true") : F("false"));
    Serial.print(F(",\"ito_pattern\":["));
    for (int i = 0; i < NUM_ITO; i++) { if (i) Serial.print(','); Serial.print(ito[i]); }
    Serial.print(F("],\"telemetry\":["));
    for (int i = 0; i < tel_n; i++) { if (i) Serial.print(','); Serial.print(tel[i]); }
    Serial.print(F("]}"));
  }
  Serial.println(F("}"));
}

static void run_full() {
  ex_reset();
  cpu_reset();
  int attempts = 0;
  if (!generate_matrix(1000, &attempts)) { Serial.println(F("ERR,MATRIX_GEN")); return; }
  Serial.print(F("OK,MATRIX_GENERATED,")); Serial.println(attempts);
#if HAVE_GATES
  if (engine == ENG_GATES) {
    if (!gates_job_ok()) { Serial.println(F("ERR,GATE_PROGRAM_JOB_MISMATCH")); return; }
    if (gate_optical && !gate_cal_ok && !gate_calibrate()) { Serial.println(F("ERR,GATE_CAL_LOW_SWING")); return; }
  }
#endif
#if HAVE_CHAIN
  if (engine == ENG_CHAIN) {
    if (!gates_job_ok()) { Serial.println(F("ERR,GATE_PROGRAM_JOB_MISMATCH")); return; }
    if (memcmp(CP_TARGET, target, 32) != 0) { Serial.println(F("ERR,CHAIN_TARGET_MISMATCH")); return; }
    if (gate_optical && !gate_cal_ok && !gate_calibrate()) { Serial.println(F("ERR,GATE_CAL_LOW_SWING")); return; }
  }
#endif
  if (engine == ENG_MIX) {
    if (mix_nib_every && !opt_cal_ok && !optical_calibrate()) { Serial.println(F("ERR,OPT_CAL_LOW_SWING")); return; }
#if HAVE_GATES
    if (mix_gate_every) {
      if (!gates_job_ok()) { Serial.println(F("ERR,GATE_PROGRAM_JOB_MISMATCH")); return; }
      if (gate_optical && !gate_cal_ok && !gate_calibrate()) { Serial.println(F("ERR,GATE_CAL_LOW_SWING")); return; }
    }
#endif
  }
  memset(eng_hashes, 0, sizeof(eng_hashes)); memset(eng_us, 0, sizeof(eng_us)); mix_counter = 0;
  gate_waves_run = 0; gate_decisions = 0; gate_wrong = 0;
  clear_optics();
  opt_hashes = 0; opt_mismatch = 0; opt_false_hits = 0; opt_counter = 0;
  uint64_t tried_total = 0, nonce = 0;
  uint8_t hash[32];
  int res = 0;
  uint32_t t0 = millis();

  while (tried_total < max_nonces) {
    uint64_t chunk = max_nonces - tried_total;
    if (chunk > 4096) chunk = 4096;
    uint64_t tried = 0;
    res = search(start_nonce + tried_total, chunk, &nonce, hash, &tried, true);
    tried_total += tried;
    if (res == 1) {  // never accept a hit the independent implementation disagrees with
      uint8_t chk[32];
      ref_kheavy_hash(nonce, chk);
      bool hit_ok = memcmp(chk, hash, 32) == 0 && hash_meets_target(chk);
      ex_note(ex_hit, hit_ok);
      if (!hit_ok) {
        opt_false_hits++;
        res = 0;  // discard optical false positive, keep searching
      }
    }
    if (res != 0) break;
    Serial.print(F("OK,PROGRESS,")); print_u64_dec(tried_total); Serial.println();
  }

  float elapsed = (millis() - t0) / 1000.0f;
  run_total_us = (uint64_t)(elapsed * 1000000.0f);

  if (res == 1) {
    uint8_t ref[32];
    ref_kheavy_hash(nonce, ref);
    bool verified = memcmp(ref, hash, 32) == 0 && hash_meets_target(ref);

    uint8_t ito[NUM_ITO];
    for (int i = 0; i < NUM_ITO; i++) ito[i] = hash[i];
    update_optics(hash);
    delay(5);  // let the pixels settle before sampling

    uint16_t tel[64];
    int tel_n = 0;
    read_telemetry(tel, &tel_n);

    Serial.print(F("FOUND,")); print_hex64(nonce); Serial.print(',');
    print_hex_bytes(hash, 32); Serial.println();

    Serial.print(F("CSV,")); print_hex64(nonce); Serial.print(',');
    print_hex_bytes(hash, 32); Serial.print(',');
    for (int i = 0; i < NUM_ITO; i++) { if (i) Serial.print('/'); Serial.print(ito[i]); }
    Serial.print(','); Serial.print(millis());
    for (int i = 0; i < tel_n; i++) { Serial.print(','); Serial.print(tel[i]); }
    Serial.println();

    report_json(true, nonce, hash, verified, tried_total, elapsed, ito, tel, tel_n, attempts);
  } else {
    if (res == -1) Serial.println(F("OK,STOPPED"));
    else { Serial.print(F("NONE,")); print_hex64(tried_total); Serial.println(); }
    report_json(false, 0, NULL, false, tried_total, elapsed, NULL, NULL, 0, attempts);
    clear_optics();
  }
}

// ---------------------------------------------------------------------------
// Command handling
// ---------------------------------------------------------------------------

static void opt_test() {
  int att = 0;
  if (!matrix_loaded && !generate_matrix(1000, &att)) { Serial.println(F("ERR,MATRIX_GEN")); return; }
  if (!optical_calibrate()) { Serial.println(F("ERR,OPT_CAL_LOW_SWING")); return; }
  uint8_t v[64];
  for (int i = 0; i < 64; i++) v[i] = (uint8_t)((i * 7 + 3) & 0x0f);
  uint16_t p[64], d[64];
  uint32_t t0 = millis();
  matvec_optical(v, p);
  uint32_t ms = millis() - t0;
  matvec_digital(v, d);
  int exact = 0, nib_bad = 0, max_err = 0;
  for (int i = 0; i < 64; i++) {
    int e = (int)p[i] - (int)d[i];
    if (e < 0) e = -e;
    if (e > max_err) max_err = e;
    if (e == 0) exact++;
    if (((p[i] >> 10) & 0x0f) != ((d[i] >> 10) & 0x0f)) nib_bad++;
  }
  Serial.print(F("OK,OPTTEST,rows_exact=")); Serial.print(exact);
  Serial.print(F(",nibble_mismatch_rows=")); Serial.print(nib_bad);
  Serial.print(F(",max_abs_err=")); Serial.print(max_err);
  Serial.print(F(",ms_per_matvec=")); Serial.println(ms);
}

static void print_skeleton() {
  Serial.println(F("SK,hash(nonce)  -- ENGINE CHAIN: the logic is done by LED pulses through the ITO plate"));
  Serial.println(F("SK,+- CPU   glue : state = st_pow0 ^ block(pre_pow, ts, nonce)  [136 byte XORs of constants]"));
  Serial.println(F("SK,+- OPTICS keccak-f = round program x24"));
#if HAVE_CHAIN
  Serial.print(F("SK,|    round program: ")); Serial.print((unsigned)RP_N_GATES);
  Serial.print(F(" gates in ")); Serial.print((unsigned)RP_N_WAVES); Serial.println(F(" waves"));
#endif
  Serial.println(F("SK,|    +- CPU   : load 1600 state bits + 64 round-constant bits into wires"));
  Serial.println(F("SK,|    +- per wave (8 gates = 8 lanes):"));
  Serial.println(F("SK,|    |    +- ITO[k] shows a_k   -> LED_A pulse -> LED_A off"));
  Serial.println(F("SK,|    |    +- ITO[k] shows b_k   -> LED_B pulse -> LED_B off"));
  Serial.println(F("SK,|    |    +- MUX selects k      -> PD[k] holds s = a+b -> ADC read"));
  Serial.println(F("SK,|    |    +- CPU   : threshold s to 0/1/2, truth-table lookup, store bit (readout)"));
  Serial.println(F("SK,|    +- CPU   : read 1600 state bits back"));
  Serial.println(F("SK,+- OPTICS heavy program (nibble matrix x vector + XOR) -- same wave loop"));
#if HAVE_GATES
  Serial.print(F("SK,|    heavy program: ")); Serial.print((unsigned)GP_N_GATES);
  Serial.print(F(" gates in ")); Serial.print((unsigned)GP_N_WAVES); Serial.println(F(" waves"));
#endif
  Serial.println(F("SK,+- CPU   glue : state = st_heavy0 ^ block(transformed)"));
  Serial.println(F("SK,+- OPTICS keccak-f = round program x24"));
  Serial.println(F("SK,+- OPTICS cmp program: hash <= target -> single hit bit"));
  Serial.println(F("SK,+- CPU   : read the hit bit; on a hit only: native reference re-check (ref_kheavy_hash)"));
  Serial.println(F("SK,CPU never computes Keccak/matvec/gates natively in chain mode (see CPUSTATS: native_* = 0)."));
}

static char *next_tok(char **p) {
  char *s = *p;
  while (*s == ' ') s++;
  if (!*s) { *p = s; return NULL; }
  char *start = s;
  while (*s && *s != ' ') s++;
  if (*s) *s++ = 0;
  *p = s;
  return start;
}

static void handle_line(char *line) {
  char *rest = line;
  char *cmd = next_tok(&rest);
  if (!cmd) return;
  for (char *c = cmd; *c; c++) if (*c >= 'a' && *c <= 'z') *c -= 32;

  if (!strcmp(cmd, "PING")) {
    Serial.println(F("OK,PONG"));

  } else if (!strcmp(cmd, "MODE")) {
    char *m = next_tok(&rest);
    if (!m) { Serial.println(F("ERR,MODE syntax")); return; }
    if (!strcasecmp(m, "PHOTODIODES")) { source = SRC_PHOTODIODES; Serial.println(F("OK,MODE_PHOTODIODES")); }
    else if (!strcasecmp(m, "CAMERA")) { source = SRC_CAMERA; Serial.println(F("OK,MODE_CAMERA")); }
    else if (!strcasecmp(m, "NONE")) { source = SRC_NONE; Serial.println(F("OK,MODE_NONE")); }
    else Serial.println(F("ERR,MODE syntax"));

  } else if (!strcmp(cmd, "SAMPLE")) {
    send_sample();

  } else if (!strcmp(cmd, "ITOCLEAR")) {
    clear_optics();
    Serial.println(F("OK,ITOCLEAR"));

  } else if (!strcmp(cmd, "ITOEVERY")) {
    uint64_t n = parse_u64(next_tok(&rest));
    ito_every = n ? (uint32_t)n : 1;
    Serial.println(F("OK,ITOEVERY"));

  } else if (!strcmp(cmd, "SETITO")) {
    int vals[NUM_ITO];
    for (int i = 0; i < NUM_ITO; i++) {
      char *t = next_tok(&rest);
      if (!t) { Serial.println(F("ERR,SETITO syntax")); return; }
      for (char *c = t; *c; c++) if (*c < '0' || *c > '9') { Serial.println(F("ERR,SETITO syntax")); return; }
      vals[i] = constrain((int)parse_u64(t), 0, 255);
    }
    if (next_tok(&rest)) { Serial.println(F("ERR,SETITO syntax")); return; }
    for (int i = 0; i < NUM_ITO; i++) analogWrite(ITO_PINS[i], vals[i]);
    Serial.println(F("OK,SETITO"));

  } else if (!strcmp(cmd, "MATRIXROW")) {
    char *r = next_tok(&rest);
    char *hex = next_tok(&rest);
    if (!r || !hex) { Serial.println(F("ERR,MATRIXROW syntax")); return; }
    int row = (int)parse_u64(r);
    if (row < 0 || row >= 64) { Serial.println(F("ERR,MATRIXROW index")); return; }
    if (!hex_to_bytes(hex, matrix[row], 64)) { Serial.println(F("ERR,MATRIXROW hex")); return; }
    pack_row(row);
    matrix_loaded = true;
    Serial.println(F("OK,MATRIXROW"));

  } else if (!strcmp(cmd, "GENMATRIX")) {
    int attempts = 0;
    if (generate_matrix(1000, &attempts)) { Serial.print(F("OK,MATRIX_GENERATED,")); Serial.println(attempts); }
    else Serial.println(F("ERR,MATRIX_GEN"));

  } else if (!strcmp(cmd, "PREPOW")) {
    if (!hex_to_bytes(next_tok(&rest), pre_pow, 32)) { Serial.println(F("ERR,PREPOW hex")); return; }
    matrix_loaded = false;
    Serial.println(F("OK,PREPOW"));

  } else if (!strcmp(cmd, "WORKORDER")) {
    uint8_t work[80];
    if (!hex_to_bytes(next_tok(&rest), work, 80)) { Serial.println(F("ERR,WORKORDER hex")); return; }
    cshake256(work, 80, "ProofOfWorkHash", pre_pow, 32);
    matrix_loaded = false;
    Serial.println(F("OK,WORKORDER"));

  } else if (!strcmp(cmd, "DEMO")) {
    load_demo_template();
    matrix_loaded = false;
    Serial.println(F("OK,DEMO"));

  } else if (!strcmp(cmd, "TIMESTAMP")) {
    timestamp = parse_u64(next_tok(&rest));
    Serial.println(F("OK,TIMESTAMP"));

  } else if (!strcmp(cmd, "TARGETBITS")) {
    target_from_leading_zero_bits((int)parse_u64(next_tok(&rest)));
    Serial.println(F("OK,TARGETBITS"));

  } else if (!strcmp(cmd, "TARGET")) {
    if (!hex_to_bytes(next_tok(&rest), target, 32)) { Serial.println(F("ERR,TARGET hex")); return; }
    Serial.println(F("OK,TARGET"));

  } else if (!strcmp(cmd, "START")) {
    start_nonce = parse_u64(next_tok(&rest));
    Serial.println(F("OK,START"));

  } else if (!strcmp(cmd, "MAXNONCES")) {
    max_nonces = parse_u64(next_tok(&rest));
    Serial.println(F("OK,MAXNONCES"));

  } else if (!strcmp(cmd, "BATCH")) {
    uint64_t n = parse_u64(next_tok(&rest));
    batch_size = n ? (uint32_t)n : 1;
    Serial.println(F("OK,BATCH"));

  } else if (!strcmp(cmd, "ENGINE")) {
    char *m = next_tok(&rest);
    if (m && !strcasecmp(m, "DIGITAL")) { engine = ENG_DIGITAL; Serial.println(F("OK,ENGINE_DIGITAL")); }
    else if (m && !strcasecmp(m, "CHAIN")) {
#if HAVE_CHAIN
      if (gate_optical && !gate_calibrate()) { Serial.println(F("ERR,GATE_CAL_LOW_SWING")); return; }
      engine = ENG_CHAIN;
      Serial.println(F("OK,ENGINE_CHAIN"));
#else
      Serial.println(F("ERR,NO_CHAIN_PROGRAM"));
#endif
    }
    else if (m && !strcasecmp(m, "GATES")) {
#if HAVE_GATES
      if (gate_optical && !gate_calibrate()) { Serial.println(F("ERR,GATE_CAL_LOW_SWING")); return; }
      engine = ENG_GATES;
      Serial.println(F("OK,ENGINE_GATES"));
#else
      Serial.println(F("ERR,NO_GATE_PROGRAM"));
#endif
    }
    else if (m && !strcasecmp(m, "OPTICAL")) {
      if (!optical_calibrate()) { Serial.println(F("ERR,OPT_CAL_LOW_SWING")); return; }
      engine = ENG_OPTICAL;
      Serial.println(F("OK,ENGINE_OPTICAL"));
    } else Serial.println(F("ERR,ENGINE syntax"));

  } else if (!strcmp(cmd, "GATEMODE")) {
    char *m = next_tok(&rest);
    if (m && !strcasecmp(m, "OPTICAL")) { gate_optical = true; gate_cal_ok = false; Serial.println(F("OK,GATEMODE_OPTICAL")); }
    else if (m && !strcasecmp(m, "DIGITAL")) { gate_optical = false; Serial.println(F("OK,GATEMODE_DIGITAL")); }
    else Serial.println(F("ERR,GATEMODE syntax"));

  } else if (!strcmp(cmd, "GATETEST")) {
#if HAVE_GATES
    gate_test();
#else
    Serial.println(F("ERR,NO_GATE_PROGRAM"));
#endif

  } else if (!strcmp(cmd, "OPTCAL")) {
    if (optical_calibrate()) Serial.println(F("OK,OPTCAL"));
    else Serial.println(F("ERR,OPT_CAL_LOW_SWING"));

  } else if (!strcmp(cmd, "OPTTEST")) {
    opt_test();

  } else if (!strcmp(cmd, "OPTSLOT")) {
    uint64_t n = parse_u64(next_tok(&rest));
    opt_slot_us = n ? (uint32_t)n : 1;
    opt_cal_ok = false;  // recalibrate after timing changes
    gate_cal_ok = false;
    Serial.println(F("OK,OPTSLOT"));

  } else if (!strcmp(cmd, "OPTEVERY")) {
    uint64_t n = parse_u64(next_tok(&rest));
    opt_every = n ? (uint32_t)n : 1;
    Serial.println(F("OK,OPTEVERY"));

  } else if (!strcmp(cmd, "OPTTRUST")) {
    opt_trust = parse_u64(next_tok(&rest)) != 0;
    Serial.println(F("OK,OPTTRUST"));

  } else if (!strcmp(cmd, "MIX")) {
    // MIX <nibble_every> <gate_every>: every n-th hash goes through that optical engine,
    // the rest run on the CPU. 0 turns an engine off. Example: MIX 64 512
    uint64_t n = parse_u64(next_tok(&rest));
    uint64_t g = parse_u64(next_tok(&rest));
#if !HAVE_GATES
    if (g) { Serial.println(F("ERR,NO_GATE_PROGRAM")); return; }
#endif
    mix_nib_every = (uint32_t)n;
    mix_gate_every = (uint32_t)g;
    engine = ENG_MIX;
    Serial.print(F("OK,MIX,nibble_every=")); Serial.print((unsigned)mix_nib_every);
    Serial.print(F(",gate_every=")); Serial.println((unsigned)mix_gate_every);

  } else if (!strcmp(cmd, "TRACE")) {
    trace_left = (int32_t)parse_u64(next_tok(&rest));  // print the next n device events (T,...)
    Serial.println(F("OK,TRACE"));

  } else if (!strcmp(cmd, "SHADOW")) {
    shadow = parse_u64(next_tok(&rest)) != 0;  // 0: CPU computes no ideal gate values (optics only)
    Serial.println(shadow ? F("OK,SHADOW_ON") : F("OK,SHADOW_OFF_optics_only"));

  } else if (!strcmp(cmd, "CPUSTATS")) {
    cpu_print();

  } else if (!strcmp(cmd, "SKELETON")) {
    print_skeleton();

  } else if (!strcmp(cmd, "EXSTATS")) {
    char *m = next_tok(&rest);
    ex_print(m && !strcasecmp(m, "ALL"));  // EXSTATS ALL also lists unused rows

  } else if (!strcmp(cmd, "EXRESET")) {
    ex_reset();
    Serial.println(F("OK,EXRESET"));

  } else if (!strcmp(cmd, "EXLOG")) {
    ex_log_left = (int32_t)parse_u64(next_tok(&rest));  // print the next n failed exchanges live (XF,...)
    Serial.println(F("OK,EXLOG"));

  } else if (!strcmp(cmd, "RUN")) {
    run_full();

  } else if (!strcmp(cmd, "JOB")) {
    // Legacy: JOB <pre_pow> <timestamp> <target> <start_nonce> <count>; uses the loaded matrix.
    if (!matrix_loaded) { Serial.println(F("ERR,MATRIX_NOT_LOADED")); return; }
    char *a = next_tok(&rest), *b = next_tok(&rest), *c = next_tok(&rest);
    char *d = next_tok(&rest), *e = next_tok(&rest);
    if (!a || !b || !c || !d || !e) { Serial.println(F("ERR,JOB syntax")); return; }
    if (!hex_to_bytes(a, pre_pow, 32) || !hex_to_bytes(c, target, 32)) { Serial.println(F("ERR,JOB hex")); return; }
    timestamp = parse_hex64(b);
    uint64_t first = parse_hex64(d), count = parse_hex64(e);

    uint64_t nonce = 0, tried = 0;
    uint8_t hash[32];
    if (search(first, count, &nonce, hash, &tried, false) == 1) {
      Serial.print(F("FOUND,")); print_hex64(nonce); Serial.print(',');
      print_hex_bytes(hash, 32); Serial.println();
    } else {
      Serial.print(F("NONE,")); print_hex64(count); Serial.println();
    }

  } else {
    Serial.println(F("ERR,UNKNOWN_COMMAND"));
  }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  for (int i = 0; i < 3; ++i) {
    pinMode(MUX_SELECT_PINS[i], OUTPUT);
    digitalWrite(MUX_SELECT_PINS[i], LOW);
  }
  pinMode(PHOTO_ADC_PIN, INPUT);
  pinMode(LED_A_PIN, OUTPUT);
  pinMode(LED_B_PIN, OUTPUT);
  leds(false, false);
  for (int i = 0; i < NUM_ITO; i++) {
    pinMode(ITO_PINS[i], OUTPUT);
    analogWrite(ITO_PINS[i], 0);
  }

  init_hash_states();
  load_demo_template();
  target_from_leading_zero_bits(12);  // easy bench target

  uint32_t t0 = millis();
  while (!Serial && millis() - t0 < 4000) delay(10);

  Serial.println(F("OK,READY"));

#if AUTO_RUN_ON_BOOT
  Serial.println(F("OK,AUTORUN_DEMO"));
  run_full();
#endif
}

void loop() {
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      line_buf[line_len] = 0;
      handle_line(line_buf);
      line_len = 0;
    } else if (line_len < sizeof(line_buf) - 1) {
      line_buf[line_len++] = c;
    } else {
      line_len = 0;
      Serial.println(F("ERR,LINE_TOO_LONG"));
    }
  }
}
